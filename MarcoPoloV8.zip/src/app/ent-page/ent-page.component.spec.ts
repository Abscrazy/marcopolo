import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntPageComponent } from './ent-page.component';

describe('EntPageComponent', () => {
  let component: EntPageComponent;
  let fixture: ComponentFixture<EntPageComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EntPageComponent]
    });
    fixture = TestBed.createComponent(EntPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

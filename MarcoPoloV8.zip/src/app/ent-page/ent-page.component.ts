import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap,map } from 'rxjs/operators';
import { MatTableDataSource } from '@angular/material/table';


@Component({
  selector: 'app-ent-page',
  templateUrl: './ent-page.component.html',
  styleUrls: ['./ent-page.component.scss']
})
export class EntPageComponent implements OnInit {
  dataSource: MatTableDataSource<any> = new MatTableDataSource<any>();
  columns: string[] = [];
  values: string[] = [];
  data: any[] = [];
  item: any;
  tab_id: string = '';
  name: string = '';
  constructor(private route: ActivatedRoute,private http: HttpClient) { }
  
  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      const item = JSON.parse(JSON.stringify(params));
      this.tab_id = item['tab-id']
      this.name = item['name']
      console.log(item);
    });
    this.load_entity(this.tab_id, this.name);
  }

  load_entity(tab_id: string, name: string) {
    const url = 'http://20.102.105.74:105/metadata/';
  
    this.http.post<any>(url, { tab_id, name }).pipe(
      tap((data) => {
        console.log(data);
        this.data = data;
        console.log(this.data);
        this.columns = Object.keys(data);
        this.values = Object.values(data);
        console.log(this.values);
      })
    ).subscribe({
      complete: () => {
        console.log('Search request completed');
      },
      error: (error) => {
        console.error('An error occurred:', error);
      }
    });
  }

  isObject(value: any): boolean {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
  }
  
}



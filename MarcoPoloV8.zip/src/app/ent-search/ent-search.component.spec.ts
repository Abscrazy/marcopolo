import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntSearchComponent } from './ent-search.component';

describe('EntSearchComponent', () => {
  let component: EntSearchComponent;
  let fixture: ComponentFixture<EntSearchComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EntSearchComponent]
    });
    fixture = TestBed.createComponent(EntSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

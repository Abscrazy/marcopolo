import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap,map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { KeyValuePipe } from '@angular/common';
import { MatTableDataSource } from '@angular/material/table';
import { AfterViewInit, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MatMenuTrigger } from '@angular/material/menu';
import { EChartsOption } from 'echarts';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-ent-search',
  templateUrl: './ent-search.component.html',
  styleUrls: ['./ent-search.component.scss'],
  providers: [KeyValuePipe],
})
export class EntSearchComponent {
  placeId: string = '';
  arr: any[] = [];
  totData: any[] = [];
  dataSource: MatTableDataSource<any> = new MatTableDataSource<any>();
  displayedColumns: string[] = ['name','location', 'dbname','id','database', 'r_id'];
  columns: string[] = [];
  filteredItems: any[] = [];
  options!: Observable<EChartsOption>;

  constructor(private http: HttpClient) {}

  menuTopLeftPosition = { x: 0, y: 0 };
  @ViewChild(MatMenuTrigger, { static: true }) matMenuTrigger!: MatMenuTrigger;

    onChartClick(ec: any) {
        console.log(ec.event.event);
        this.menuTopLeftPosition.x = ec.event.event.clientX;
        this.menuTopLeftPosition.y = ec.event.event.clientY;
        this.matMenuTrigger.openMenu();
    }

    onChartrightClick(ec: any) {
      console.log(ec.event.event);
      window.open('//www.google.com', '_blank');
    }


  ngOnInit(): void {
    this.makeSearchRequest();
    //this.startList();
  }

  makeSearchRequest() {
    const url = 'http://20.102.105.74:105/tables/';
    
    this.http.get<any>(url, {}).pipe(
      tap((data) => {
        console.log(data);
        this.dataSource = new MatTableDataSource(data);
        this.totData = data;
        this.arr = data;
        this.columns = Object.keys(data[0]);
      })
    ).subscribe({
      complete: () => {
        console.log('Search request completed');
      },
      error: (error) => {
        console.error('An error occurred:', error);
      }
    });
  }

  applyFilter(filterValue: string) {
    this.dataSource.filterPredicate = (data: any, filter: string) => {
      // Replace 'name' with the actual property name in your data object for the name column
      return data.name.toLowerCase().includes(filter);
    };
    
    const trimmedFilterValue = filterValue.trim().toLowerCase();
    this.dataSource.filter = trimmedFilterValue;
  
    // Update the filteredItems array with the filtered data
    this.filteredItems = this.dataSource.filteredData;
    this.getlineage();
  }

  getlineage(){
    this.options = this.http
    .post<any>('http://20.102.105.74:105/getlin/', {
        data : this.filteredItems
    })
    .pipe(
        map((data) => {
            console.log(data);
            return {
                tooltip: {},
                animationDurationUpdate: 1500,
                animationEasingUpdate: 'quinticInOut',
                series: [
                    {
                        type: 'graph',
                        layout: 'force',
                        symbol : 'rect',
                        autoCurveness : true,
                        symbolSize : [100,55],
                        roam: true,
                        draggable : true,
                        force:{
                            repulsion : 800,
                            edgeLength : 250
                        },
                        emphasis : {
                            focus : "adjacency",
                            blurScope: 'global',
                            itemStyle: {
                                color : "rgb(244,245,247)"
                            },
                            lineStyle: {
                                color : "#000"
                            }
                          },
                        label: {
                            show: true,
                        },
                        edgeSymbol: ['none', 'arrow'],
                        edgeSymbolSize: [4, 10],
                        edgeLabel: {
                            fontSize: 20,
                        },
                        data: data.nodes,
                        links: data.links,
                        itemStyle :{
                            color : "#fff",
                            borderColor : "rgb(26,99,255)",
                            borderCap : "round",
                            borderJoin : "round"
                        },
                        lineStyle: {
                            cap : "square",
                            opacity: 0.9,
                            width: 2,
                        },
                    },
                ],
            };
        })
    );
  }
}
